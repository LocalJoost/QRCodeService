## [3.2.0] - 2024-05-15

### Added

* Added unified font atlas and updated corresponding fonts and their materials. [PR #700](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/700)

## [3.1.0] - 2024-02-09

### Added

* Added SimpleEmptyButton (Experimental) and SimpleActionButton (Experimental) prefabs plus corresponding (Experimental) assets and demoscene. [PR #635](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/635)

### Fixed    
  
* Fixed support for UPM package publishing in the Unity Asset Store. [PR #519](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/519)
* Fixing shaders of a couple of TMPro fonts [PR #696](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/696)
* Set the Data packages's CooperHewitt-BoldItalic SDK shader to the Graphic Tools TMPro shader [PR #696](https://github.com/MixedRealityToolkit/MixedRealityToolkit-Unity/pull/696)